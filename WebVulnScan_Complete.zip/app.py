from flask import Flask, render_template, request
from scanner.xss_scanner import check_xss
from scanner.scraper import scrape_links

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    result = ""
    if request.method == 'POST':
        url = request.form['url']
        links = scrape_links(url)
        result = check_xss(links)
    return render_template('index.html', result=result)

if __name__ == '__main__':
    app.run(debug=True)
