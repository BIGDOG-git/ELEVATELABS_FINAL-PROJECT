import requests
from bs4 import BeautifulSoup

def scrape_links(url):
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        return [a.get('href') for a in soup.find_all('a') if a.get('href')]
    except Exception as e:
        return [f"Error scraping {url}: {str(e)}"]
