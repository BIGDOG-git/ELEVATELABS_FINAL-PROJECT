def check_xss(links):
    result = []
    for link in links:
        if link and "<script>" in link.lower():
            result.append(f"Potential XSS found in link: {link}")
        else:
            result.append(f"Clean: {link}")
    return result
